<template>
  <div>
    <h1>Provincias:</h1>
    <ul v-if="locations && locations.length">
      <li v-for="(location, index) in locations" :key="index">
        <strong>{{ location.id }}</strong> - {{ location.nombre }}
      </li>
    </ul>

    <ul v-if="errors && errors.length">
      <li v-for="(error, index) in errors" :key="index">
        {{error.message}}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      locations: [],
      errors: []
    }
  },

  // Fetches posts when the component is created.
  created() {
    axios.get('https://apis.datos.gob.ar/georef/api/provincias')
          .then(response => {
          // JSON responses are automatically parsed.
          this.locations = response.data.provincias;
          })
          .catch(e => {
            this.errors.push(e)
          })
  }
}
</script>
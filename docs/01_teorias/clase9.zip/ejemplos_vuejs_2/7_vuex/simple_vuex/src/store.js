import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
  state () {
    return {
      count: 0
    }
  },
  mutations: {
    increment (state, payload) {
        state.count += payload.amount
    },
    decrement (state, payload) {
        state.count -= payload.amount
    }
  }
})

export default store
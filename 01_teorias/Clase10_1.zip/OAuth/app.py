from src.web import create_app
from pathlib import Path

static_folder = Path(__file__).parent.absolute().joinpath("public")

app = create_app(env="development", static_folder=static_folder)


def main():
    app.run() #ssl_context="adhoc"


if __name__ == "__main__":
    main()

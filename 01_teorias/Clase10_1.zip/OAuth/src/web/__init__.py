from flask import Flask, url_for, render_template, session, redirect
from os import environ, urandom
from src.web.config import config
from authlib.integrations.flask_client import OAuth



def create_app(env="development", static_folder="static"):
    app = Flask(__name__, static_folder=static_folder)

    app.secret_key = environ.get("SECRET_KEY") or urandom(24)

    app.config.from_object(config[env])

    CONF_URL = 'https://accounts.google.com/.well-known/openid-configuration'
    oauth = OAuth(app)
    oauth.register(
        name='google',
        server_metadata_url=CONF_URL,
        client_kwargs={
            'scope': 'openid email profile'
        }
    )

    @app.route('/')
    def homepage():
        user = session.get('user')
        return render_template('index.html', user=user)

    @app.route('/login')
    def login():
        redirect_uri = url_for('auth', _external=True)
        return oauth.google.authorize_redirect(redirect_uri)

    # @app.route('/auth')
    # def auth():
    #     token = oauth.google.authorize_access_token()
    #     session['user'] = token['userinfo']
    #     return redirect('/')

    @app.route('/login/callback')
    def auth():
        token = oauth.google.authorize_access_token()
        print(token['userinfo'].keys())
        session['user'] = token['userinfo']
        return redirect('/')

    @app.route('/logout')
    def logout():
        session.pop('user', None)
        return redirect('/')

    return app

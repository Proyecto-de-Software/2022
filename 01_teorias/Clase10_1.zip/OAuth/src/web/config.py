from os import environ
import os


class Config(object):
    """Base configuration."""

    SECRET_KEY = "secret"
    DEBUG = False
    TESTING = False
    SESSION_TYPE = "filesystem"
    SESSION_PERMANENT = False


class ProductionConfig(Config):
    """Production configuration."""
    DB_SERVER = environ.get("DB_SERVER")
    DB_DATABASE = environ.get("DB_DATABASE")
    DB_USER = environ.get("DB_USER")
    DB_PASSWORD = environ.get("DB_PASSWORD")
    DB_PORT = environ.get("DB_PORT")
    SQLALCHEMY_DATABASE_URI = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_SERVER}:{DB_PORT}/{DB_DATABASE}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID')
    GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET')
    SESSION_TYPE = "filesystem"


class DevelopmentConfig(Config):
    """Development configuration."""

    DB_SERVER = environ.get("DB_SERVER", "localhost")
    DB_DATABASE = environ.get("DB_DATABASE", "proyecto_db")
    DB_USER = environ.get("DB_USER", "proyecto_db")
    DB_PASSWORD = environ.get("DB_PASSWORD", "proyecto_db")
    DB_PORT = environ.get("DB_PORT", "5432")
    SQLALCHEMY_DATABASE_URI = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_SERVER}:{DB_PORT}/{DB_DATABASE}"
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID')
    GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET')
    SESSION_TYPE = "filesystem"


class TestingConfig(Config):
    """Testing configuration."""

    TESTING = True


config = {
    "development": DevelopmentConfig,
    "test": TestingConfig,
    "production": ProductionConfig,
}
<template>
  <div v-if="isLoggedIn" style="float:right">
    Welcome: {{authUser.name}} <button type="button" @click="logoutUser">Logout</button>
  </div>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link> |
    <router-link to="/login">Login</router-link>
  </nav>
  <router-view/>
</template>

<script>
  import {  mapActions, mapGetters } from 'vuex'
  export default {
    computed: {
      ...mapGetters({
        authUser: 'auth/user',
        isLoggedIn: 'auth/isLoggedIn'
      })
    },
    methods: {
      ...mapActions('auth',['logoutUser']),
    }
  }
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>

# Ejemplo Flask <-jwt-> Vue (en cookies)

## En **docker-compose.yml** estan los servicios

- db: servidor de base de datos postgres.
- pgadmin: aplicación pgAdmin 4.

## Carpeta **admin**

Aplicación backend en flask (con Flask-JWT-Extended):

- poetry install
- poetry run flask resetdb
- poetry run flask seeds
- poetry run flask run 

Antes debemos crear la base de datos vacía **proyecto**.
El servidor queda levantado en el puerto 5000.

## Carpeta **frontend**

Aplicación frontend de vue (router+vuex): 

- npm install
- npm run serve (o **vue serve** si tenemos vue cli)


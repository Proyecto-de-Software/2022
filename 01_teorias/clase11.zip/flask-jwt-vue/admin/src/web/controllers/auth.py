from flask import Blueprint
from flask import render_template
from flask import flash
from flask import request, jsonify
from flask import redirect
from flask import url_for
from flask import session
from flask import g

from src.core import auth

from flask_jwt_extended import create_access_token, create_refresh_token, set_access_cookies, set_refresh_cookies
from flask_jwt_extended import unset_jwt_cookies, jwt_required
from flask_jwt_extended import get_jwt_identity

auth_blueprint = Blueprint("auth", __name__, url_prefix="/auth")


@auth_blueprint.get("/")
def login():
    return render_template("auth/login.html")


@auth_blueprint.post("/authenticate")
def authenticate():
    params = request.form

    user = auth.find_user_by_email_and_pass(params["email"], params["password"])

    if not user:
        flash("Usuario o clave incorrecto.", "error")
        return redirect(url_for("auth.login"))

    session["user"] = user.email
    flash("La sesión se inició correctamente.", "success")

    return redirect(url_for("home"))


@auth_blueprint.get("/logout")
def logout():
    del session["user"]
    session.clear()
    flash("La sesión se cerró correctamente.", "info")

    return redirect(url_for("auth.login"))

# SQLi
@auth_blueprint.post("/authenticate_sqli")
def authenticate_sqli():
    params = request.form

    user = auth.find_user_by_email_and_pass_sqli(params['email'], params['password'])

    if not user:
        flash("Usuario o clave incorrecto.")
        return redirect(url_for('auth.login'))

    session['user'] = user.email
    flash("La sesión se inició correctamente.")

    return redirect(url_for('home'))

@auth_blueprint.post('/login_jwt')
def login_jwt():
  data = request.get_json()
  email = data['email']
  password = data['password']
  user = auth.find_user_by_email_and_pass(email, password)
   
  if user:
    access_token = create_access_token(identity=user.id)
    response = jsonify()
    set_access_cookies(response, access_token)
    return response, 201
  else:
    return jsonify(message="Unauthorized"), 401

@auth_blueprint.get('/logout_jwt')
@jwt_required( )
def logout_jwt():
  response = jsonify()
  unset_jwt_cookies(response)
  return response, 200

@auth_blueprint.get('/user_jwt')
@jwt_required( )
def user_jwt():
  current_user = get_jwt_identity()
  user = auth.get_user_by_id(current_user)
  response = jsonify(user)
  return response, 200
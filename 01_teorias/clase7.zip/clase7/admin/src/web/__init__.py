from flask import Flask
from flask import render_template
from flask_session import Session

from src.core import board
from src.core import database
from src.core import seeds
from src.web.config import config
from src.web.helpers import handler
from src.web.helpers import auth
from src.web.controllers.issue import issue_blueprint
from src.web.controllers.users import user_blueprint
from src.web.controllers.auth import auth_blueprint

import logging

logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO)


def create_app(env="development", static_folder="static"):
    app = Flask(__name__, static_folder=static_folder)

    # Import config
    app.config.from_object(config[env])

    # Server Side session
    Session(app)

    # Configure db
    db = database.init_app(app)

    # Define home
    @app.route("/")
    def home():
        return render_template("home.html")

    # Load blueprints
    app.register_blueprint(issue_blueprint)
    app.register_blueprint(user_blueprint)
    app.register_blueprint(auth_blueprint)

    # Error handlers
    app.register_error_handler(404, handler.not_found_error)
    app.register_error_handler(500, handler.generic_error)
    app.register_error_handler(401, handler.unauthorized)

    # Add to jinja
    app.jinja_env.globals.update(is_authenticated=auth.is_authenticated)

    # Commands
    @app.cli.command(name="resetdb")
    def resetdb():
        """Elimino y creo la base de datos."""
        database.init_db()

    @app.cli.command(name="seeds")
    def seedsdb():
        seeds.run()


    #SQLi
    def login_sqli():
        return render_template('auth/login_sqli.html')
    app.add_url_rule("/iniciar_sesion_sqli", 'auth_login_sqli', login_sqli)
    
    #app.add_url_rule(
    #    "/autenticacion_sqli", 'auth_authenticate_sqli', auth.authenticate_sqli, methods=['POST']
    #)
    
    # XSS
    app.add_url_rule("/ejemplo_xss", 'musician_xss', board.find_musician_xss)

    # Ajax
    def ajax():
        return render_template('ajax.html')
    app.add_url_rule("/ejemplo_ajax","ejemplo_ajax",ajax)

    # Ajax jquery
    def ajax_jquery():
        return render_template('ajax_jquery.html')
    app.add_url_rule("/ejemplo_ajax_jquery","ejemplo_ajax_jquery",ajax_jquery)

    # Ajax fetch
    def ajax_fetch():
        return render_template('ajax_fetch.html')
    app.add_url_rule("/ejemplo_ajax_fetch","ejemplo_ajax_fetch",ajax_fetch)

    # Ajax async/await
    def ajax_async_await():
        return render_template('ajax_async_await.html')
    app.add_url_rule("/ejemplo_ajax_async_await","ejemplo_ajax_async_await",ajax_async_await)

    app.add_url_rule("/musicos", 'musician_ajax', board.find_musician_by_name)
    app.add_url_rule("/all_musicos", 'all_musician_ajax', board.list_musicians)
    
    return app

# Proyecto 2022

## Componentes

- `admin` aplicación de administración.
- `portal` aplicación web pública

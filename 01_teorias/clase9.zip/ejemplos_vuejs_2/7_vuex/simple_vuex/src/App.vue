<template>
  <div id="app">
    <h1> Estado Global: count= {{ count }} </h1>

    <img alt="Vue logo" src="./assets/logo.png">
    <table width="80%" align="center">
      <tr>
        <td><Counter msg="Contador 1" :num="1" /></td>
        <td><Counter msg="Contador 2" :num="2" /></td>
        <td><Counter msg="Contador 3" :num="3" /></td>
      </tr>
    </table>
  </div>
</template>

<script>
import Counter from './components/Counter.vue'

export default {
  name: 'app',
  components: {
    Counter
  },
  computed: {
    count () {
      return this.$store.state.count
    }
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

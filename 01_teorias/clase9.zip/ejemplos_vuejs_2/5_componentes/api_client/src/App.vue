<template>
  <div id="app">
    <ApiClient/>
  </div>
</template>

<script>
import ApiClient from './components/ApiClient.vue'

export default {
  name: 'app',
  components: {
    ApiClient
  }
}
</script>

<style>
</style>